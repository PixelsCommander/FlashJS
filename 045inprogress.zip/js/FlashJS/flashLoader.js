flash.namespace('flash.display.Loader');

flash.display.Loader = (function(window, undefined){
	
	function Loader(url, handler){
		var self = new DisplayObject();
		self.loadingCallback = handler;
		self.loaded = false;
		self.url = url;
		
		self.errorOccured = function (error){
			console.log("Error loading " + self.url);
			flash.stage.removeActiveLoader();
			self.dispatchEvent(new Event(IOErrorEvent.IO_ERROR));
			delete self;
		}
		
		self.loaded = function (message){
			if (self.loadingCallback) {
				self.loadingCallback();
			}
			flash.stage.removeActiveLoader();
			self.dispatchEvent(new Event(Event.COMPLETE));		
			self.loaded = true;
		}
		
		self.startLoad = function(){
			if (self.loaded === true) return;
			var img = $('<img/>', {'src': self.url}).load(self.loaded).error(self.errorOccured);
			self.addChild(img);
			flash.stage.addActiveLoader(self);	
		}
		
		self.load = function (urlRequest){
			self.url = urlRequest.url
			
			//Commented for optimisation reasons, not needed yet
			//self.method = urlRequest.method;
			//self.request = urlRequest;
			
			self.startLoad();	
		}
		
		self.unload = function (){
			self.remove();	
		}
		
		if (url){
			self.startLoad();	
		}
		
		self.width = undefined;
		self.height = undefined;
		
		return self;
	}
	
	window.Loader = Loader;
}(window))